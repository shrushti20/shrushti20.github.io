# Shrushti Narayanaswamy — portfolio

Next.js 15 + TypeScript + Tailwind CSS v4 + Framer Motion. Exports to static HTML, so it runs on GitHub Pages for free.

## Run it locally

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # static site in ./out
```

Placeholders (`TODO` chips) are visible in `npm run dev` and hidden in the production build, so the live site never shows a gap.

## Where to edit what

| What | File |
|---|---|
| Name, links, email, GitHub username, contact-form ID | `src/config/site.ts` |
| Jobs | `src/data/experience.ts` |
| Projects and case studies | `src/data/projects.ts` |
| Thesis page | `src/data/research.ts` |
| Planned projects and roadmaps | `src/data/building.ts` |
| Skills | `src/data/skills.ts` |
| Education and certifications | `src/data/certifications.ts` |
| Colours and fonts | `src/app/globals.css` (top of the file) |
| Resume PDF, headshot, preview image | `public/` |

Nothing is hard-coded into the pages: edit the data files and the pages, the search index and the sitemap follow.

## Deploy to GitHub Pages

1. Push this folder to `https://github.com/shrushti20/shrushti20.github.io` (the repo root should contain `package.json`).
2. In the repo: **Settings → Pages → Source → GitHub Actions**.
3. Every push to `main` triggers `.github/workflows/deploy.yml`, which builds and publishes automatically.

## Still to add

- Demo links for projects, if any get deployed
- Real service names in the microservices diagram (`src/data/projects.ts`)
- IRJET paper link; certification issuers and years
- An updated `public/resume.pdf`
- Optional: a Formspree ID in `src/config/site.ts` so the contact form submits without opening an email app
