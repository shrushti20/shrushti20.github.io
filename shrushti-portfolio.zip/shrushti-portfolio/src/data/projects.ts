import type { Project } from "@/lib/types";
import { thesisPipeline } from "./research";

/**
 * Completed projects. Every claim here comes from the CV or from Shrushti
 * directly. `todo` fields mark what still needs her input; they show in
 * development and are hidden on the live site.
 */
export const projects: Project[] = [
  {
    slug: "codereview-genie",
    name: "CodeReview Genie",
    tagline: "A RAG system that answers questions about any GitHub repository, grounded in its code.",
    problem: "Understanding an unfamiliar codebase means reading dozens of files before you can answer simple questions about it.",
    status: "completed",
    hero: true,
    period: "Mar 2025 – Aug 2025",
    category: ["LLM & RAG"],
    tech: ["Python", "FastAPI", "React", "LlamaIndex", "ChromaDB", "OpenAI embeddings", "GitHub OAuth"],
    highlight: { value: "0.98", label: "average F1 across 10 evaluated repositories" },
    links: { github: "https://github.com/shrushti20/CodeReview-Genie", demo: null },
    diagram: {
      title: "CodeReview Genie architecture",
      kind: "pipeline",
      nodes: [
        { id: "repo", label: "GitHub repository", detail: "Public or private repositories. Private access goes through GitHub OAuth, so the user grants read access without sharing credentials.", tech: ["GitHub OAuth"] },
        { id: "ingest", label: "Ingestion", detail: "The repository's files are fetched and loaded as documents for indexing.", tech: ["LlamaIndex"] },
        { id: "chunk", label: "Chunking", detail: "Files are split into chunks small enough to embed and retrieve precisely.", tech: ["LlamaIndex"] },
        { id: "embed", label: "Embeddings", detail: "Each chunk is converted to a vector with OpenAI embeddings.", tech: ["OpenAI embeddings"] },
        { id: "vdb", label: "Vector database", detail: "Vectors and their source metadata are stored in ChromaDB.", tech: ["ChromaDB"] },
        { id: "retr", label: "Retriever", detail: "A question is embedded and the most similar chunks are retrieved as context.", tech: ["LlamaIndex", "ChromaDB"] },
        { id: "llm", label: "LLM", detail: "The language model answers the question using only the retrieved code as context.", tech: ["LlamaIndex"] },
        { id: "ans", label: "Answer + sources", detail: "The answer is returned to the React frontend through the FastAPI backend, together with the source context it was based on.", tech: ["FastAPI", "React"] },
      ],
    },
    caseStudy: {
      problem: {
        body: ["Getting answers about a repository you didn't write is slow. You search, open files, follow imports and piece it together yourself. CodeReview Genie lets you ask the question in plain language and answers from the repository's own code."],
      },
      why: {
        body: ["Onboarding onto a codebase, reviewing a pull request in an unfamiliar area, or checking how a feature is implemented all start with the same question: where is this, and how does it work? Grounding the answer in retrieved code keeps it tied to what the repository actually contains."],
      },
      architecture: {
        body: ["A retrieval-augmented generation pipeline: repositories are ingested, chunked, embedded and stored in a vector database. At question time the most relevant chunks are retrieved and passed to the LLM, and the answer is returned with its source context."],
      },
      tech: {
        points: [
          "FastAPI for the backend API.",
          "React for the question-and-answer interface.",
          "LlamaIndex to orchestrate ingestion, indexing and retrieval.",
          "ChromaDB as the vector store.",
          "OpenAI embeddings to represent code chunks.",
          "GitHub OAuth for secure access to private repositories.",
        ],
        todo: "Add one sentence per choice on WHY you picked it over alternatives (e.g. why ChromaDB rather than pgvector).",
      },
      implementation: {
        points: ["Repository ingestion for public and private repositories.", "Semantic retrieval over embedded code chunks.", "RAG-based question answering with source context.", "GitHub OAuth login flow."],
        todo: "Add specifics: chunk size and strategy, which LLM, how file types are handled, how sources are shown in the UI.",
      },
      challenges: { todo: "Describe 2–3 real problems you hit and how you solved them (e.g. large files, code vs. docs chunking, OAuth token handling)." },
      evaluation: {
        body: ["Evaluated on 10 GitHub repositories."],
        todo: "Explain the evaluation: how many questions per repo, how reference answers were created, and how F1 was computed.",
      },
      results: { body: ["Average F1 of 0.98 across the 10 evaluated repositories."], todo: "Add any other verified results (latency, per-repo spread, failure cases)." },
      learned: { todo: "What did building this teach you about retrieval quality and grounding?" },
      future: { todo: "What you'd add next, e.g. hybrid search, reranking, citations to exact line numbers, streaming answers." },
    },
  },
  {
    slug: "thesis",
    name: "Emotion Recognition in Argumentative Text",
    tagline: "Master's thesis on transfer learning, prompting and domain adaptation for emotion recognition in arguments.",
    problem: "Emotion classifiers trained on social media text don't transfer cleanly to argumentative text, where emotions are subtler and domain shift is large.",
    status: "completed",
    hero: true,
    period: "Oct 2025 – Apr 2026",
    category: ["NLP", "LLM & RAG"],
    tech: ["Python", "RoBERTa", "DeBERTa", "Mistral", "Zephyr", "LoRA", "RAG"],
    highlight: { value: "0.52 → 0.15", label: "DeBERTa macro-F1 from in-domain emotion data to argumentative text: the domain shift in one number" },
    links: { github: null, paper: null },
    diagram: thesisPipeline,
    caseStudy: {},
  },
  {
    slug: "microservices-beverage-system",
    name: "Microservices Beverage Storing System",
    tagline: "A containerised microservices application deployed on Kubernetes.",
    problem: "Designing an application as independently deployable services, then running and scaling it on Kubernetes.",
    status: "completed",
    period: "2024",
    category: ["Cloud & DevOps"],
    tech: ["Docker", "Kubernetes", "Minikube", "Docker Compose"],
    links: { github: null },
    diagram: {
      title: "Deployment architecture",
      kind: "cluster",
      groupLabel: "Kubernetes cluster (Minikube)",
      grouped: ["svc", "a", "b", "c", "db"],
      nodes: [
        { id: "client", label: "Client", detail: "Requests come in from outside the cluster." },
        { id: "svc", label: "Kubernetes Service", detail: "Exposes the application and routes traffic to the right pods.", tech: ["Kubernetes"] },
        { id: "a", label: "Service A", detail: "One containerised microservice, deployed as its own Deployment.", tech: ["Docker"] },
        { id: "b", label: "Service B", detail: "One containerised microservice, deployed as its own Deployment.", tech: ["Docker"] },
        { id: "c", label: "Service C", detail: "One containerised microservice, deployed as its own Deployment.", tech: ["Docker"] },
        { id: "db", label: "Storage", detail: "Persistent data for the beverage inventory." },
      ],
    },
    caseStudy: {
      problem: { body: ["Build a beverage storing application as separate microservices and deploy it to Kubernetes."] },
      architecture: {
        body: ["Each service runs in its own container. Docker Compose runs the stack locally; Minikube runs it on a local Kubernetes cluster."],
        todo: "Replace 'Service A/B/C' and 'Storage' in the diagram (src/data/projects.ts) with the real service names, what each does, and the database used.",
      },
      tech: { points: ["Docker to containerise each service.", "Docker Compose for local multi-container development.", "Kubernetes for orchestration.", "Minikube as the local Kubernetes cluster."] },
      implementation: { todo: "Describe service communication (REST? messaging?), resource requests/limits, and how deployment was automated." },
      challenges: { todo: "Add real challenges, e.g. service discovery, configuration, persistent storage." },
      learned: { todo: "What did this teach you about distributed systems?" },
      future: { todo: "e.g. Helm charts, CI/CD, autoscaling, observability." },
    },
  },
  {
    slug: "systems-programming-cpp",
    name: "Systems Programming in C++20",
    tagline: "Low-level projects: a virtual machine, heap data structures, sorting and memory utilities.",
    problem: "Understanding how software works close to the machine: memory layout, data structures and execution.",
    status: "completed",
    period: "2025 – 2026",
    category: ["Systems"],
    tech: ["C++20", "Linux", "CMake", "Makefiles", "Git", "GDB"],
    links: { github: null },
    caseStudy: {
      problem: { body: ["A set of systems-level projects built to understand how programs work below the abstractions of high-level languages."] },
      implementation: {
        points: ["Virtual machines.", "Heap data structures.", "Sorting algorithms.", "Memory representation utilities."],
        todo: "Add one line per project on what it does and one interesting design decision.",
      },
      tech: { points: ["Modern C++20 on Linux.", "Builds with CMake and Makefiles.", "Debugging with GDB.", "Version control with Git."] },
      learned: { todo: "What did low-level work change about how you write higher-level code?" },
    },
  },
  {
    slug: "rfm-segmentation",
    name: "RFM Customer Segmentation",
    tagline: "Segmenting customers by recency, frequency and monetary value in Power BI.",
    problem: "Treating every customer the same wastes marketing effort. RFM segmentation groups customers by how recently, how often and how much they buy.",
    status: "completed",
    category: ["Data"],
    tech: ["Power BI", "DAX"],
    links: { github: null },
    diagram: {
      title: "Analysis pipeline",
      kind: "pipeline",
      nodes: [
        { id: "prep", label: "Data preparation", detail: "Transaction data is cleaned and shaped for analysis." },
        { id: "rfm", label: "RFM calculation", detail: "Recency (days since last purchase), Frequency (number of purchases) and Monetary value (total spend) are calculated per customer with DAX.", tech: ["DAX"] },
        { id: "seg", label: "Segmentation", detail: "Customers are scored on each dimension and grouped into segments.", tech: ["DAX"] },
        { id: "dash", label: "Dashboard", detail: "Segments and their behaviour are visualised in Power BI.", tech: ["Power BI"] },
        { id: "ins", label: "Business insights", detail: "Segments are translated into actions for each customer group." },
      ],
    },
    caseStudy: {
      problem: { body: ["Group customers by purchasing behaviour so each group can be treated differently."] },
      implementation: {
        points: ["Data preparation.", "RFM calculation in DAX.", "Customer segmentation.", "Interactive Power BI dashboard.", "Business insights per segment."],
        todo: "Add the dataset used, the scoring method (quantiles?), segment names and a dashboard screenshot.",
      },
      results: { todo: "Add 2–3 concrete insights the dashboard revealed." },
    },
  },
  {
    slug: "ar-campus-navigation",
    name: "BIT Campus AR Navigation",
    tagline: "Android augmented-reality app for indoor navigation on the BIT campus.",
    problem: "Finding your way inside large campus buildings is hard, and GPS doesn't work indoors.",
    status: "completed",
    period: "Nov 2020 – Jul 2021",
    category: ["Mobile & AR"],
    tech: ["Unity", "Android SDK", "Metaio", "Augmented Reality"],
    links: { github: null, paper: null },
    caseStudy: {
      problem: { body: ["GPS is unreliable indoors. This app uses AR markers placed around the campus to locate the user and guide them to a destination."] },
      implementation: { points: ["Indoor navigation.", "AR marker detection.", "Campus navigation built with Unity, the Android SDK and Metaio."] },
      results: { body: ["Research related to the project was published in IRJET."], todo: "Add the paper title, year and link." },
    },
  },
];

export const getProject = (slug: string) => projects.find((p) => p.slug === slug);
