export const skills: { group: string; items: string[] }[] = [
  { group: "AI / ML", items: ["Python", "Machine Learning", "NLP", "Transformers", "RoBERTa", "DeBERTa", "LLMs", "Prompt Engineering", "LoRA", "RAG"] },
  { group: "AI infrastructure", items: ["LlamaIndex", "ChromaDB", "Embeddings", "Semantic Search", "Vector Databases"] },
  { group: "Software engineering", items: ["Python", "Java", "C++", "JavaScript", "React", "FastAPI", "REST APIs", "Git"] },
  { group: "Data", items: ["SQL", "Power BI", "DAX", "Data Modeling", "Apache Superset"] },
  { group: "Cloud / DevOps", items: ["Azure", "Docker", "Kubernetes", "Minikube", "Linux", "GitHub Actions"] },
];

export const languages = [
  { name: "English", level: "Professional working proficiency" },
  { name: "German", level: "A2, currently learning B1" },
];
