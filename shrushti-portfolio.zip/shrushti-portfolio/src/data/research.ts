import type { Diagram, Maybe } from "@/lib/types";

/**
 * Thesis content. Results are intentionally empty until verified numbers are
 * added: fill `results.rows` with real scores and the chart renders itself.
 */
export const thesis = {
  title: "Emotion Recognition in Argumentative Text",
  subtitle: "Transfer Learning, Prompting, and Domain Adaptation",
  institution: "Otto-Friedrich-Universität Bamberg",
  degree: "M.Sc. International Software Systems Science",
  period: "Oct 2025 – Apr 2026",
  supervisors: ["Lynn Greschner", "Prof. Dr. Roman Klinger"],
  links: { pdf: null as Maybe<string>, github: null as Maybe<string>, linkedin: null as Maybe<string> }, // thesis report stays unpublished by choice

  questions: [
    { id: "RQ1", title: "Cross-domain transferability", text: "How effectively do supervised emotion classifiers trained on general emotion corpora transfer to argumentative text, and which source domains enable the best cross-domain generalisation?" },
    { id: "RQ2", title: "LLM adaptation strategies", text: "How do prompting strategies (zero-shot, few-shot, chain-of-thought) affect LLM performance, and how can domain adaptation be integrated through in-context example selection?" },
    { id: "RQ3", title: "Emotion and convincingness", text: "How do predicted emotions correlate with the perceived convincingness of arguments across datasets and models?" },
  ],

  approachesTodo: "Verify which models were used with which strategy.",
  problem: [
    "Most emotion-labelled data comes from social media, while argumentative text expresses emotion more subtly. Models that work well on tweets or Reddit comments face a large domain shift when applied to arguments.",
  ],

  datasets: [
    { name: "CONTARGA", role: "Argumentative text annotated with emotions", todo: "Add size, label set, and how it was used (training / evaluation)." },
    { name: "GoEmotions", role: "Reddit comments labelled with emotions", todo: "Add how it was used, e.g. as a source domain for transfer." },
    { name: "TweetEval", role: "Tweets; emotion recognition task", todo: "Add how it was used." },
  ],

  approaches: [
    { name: "Fine-tuned encoders", detail: "RoBERTa and DeBERTa fine-tuned for emotion classification and evaluated across domains.", models: ["RoBERTa", "DeBERTa"] },
    { name: "Zero-shot prompting", detail: "Instruction-tuned LLMs classify emotions without task examples.", models: ["Mistral", "Zephyr"] },
    { name: "Few-shot prompting", detail: "The prompt includes labelled examples.", models: ["Mistral", "Zephyr"] },
    { name: "Chain-of-thought prompting", detail: "The model reasons step by step before choosing labels.", models: ["Mistral", "Zephyr"] },
    { name: "Adaptation-aware prompting", detail: "In-context examples are selected by TF-IDF similarity to the input, so the model adapts without retraining.", models: ["Mistral", "Zephyr"] },
    { name: "LoRA adaptation", detail: "Parameter-efficient fine-tuning with LoRA.", models: ["Mistral", "Zephyr"] },
  ],

  metrics: ["Macro-F1", "Precision", "Recall", "Per-class performance", "Confusion matrices"],

  /** Add verified Macro-F1 scores here, e.g. { label: "DeBERTa (fine-tuned)", value: 0.00 }. */
  results: {
    metric: "Macro-F1",
    rows: [
      { label: "DeBERTa, GoEmotions in-domain", value: 0.52 },
      { label: "RoBERTa, GoEmotions in-domain", value: 0.46 },
      { label: "DeBERTa, CONTARGA (95/class)", value: 0.225 },
      { label: "TF-IDF example selection, k=2", value: 0.184 },
      { label: "Mistral, few-shot", value: 0.169 },
      { label: "RoBERTa, CONTARGA (95/class)", value: 0.154 },
      { label: "Mistral, chain-of-thought", value: 0.153 },
      { label: "DeBERTa, GoEmotions to CONTARGA", value: 0.152 },
      { label: "Mistral, zero-shot", value: 0.15 },
      { label: "RoBERTa, GoEmotions to CONTARGA", value: 0.11 },
      { label: "Zephyr, zero-shot", value: 0.109 },
      { label: "Zephyr, few-shot", value: 0.039 },
    ] as { label: string; value: number }[],
  },

  findings: [
    "Supervised transfer to argumentative text suffers a large domain shift: DeBERTa scores 0.52 macro-F1 in-domain on GoEmotions but 0.152 on CONTARGA, and RoBERTa falls from 0.46 to 0.11.",
    "A small amount of in-domain supervision recovers part of that loss. Training on 95 CONTARGA examples per class lifts DeBERTa to 0.225 and RoBERTa to 0.154.",
    "The source dataset matters: GoEmotions and TweetEval transfer differently to argumentative text under their respective label mappings.",
    "Prompting strategy affects models unevenly. Few-shot helped Mistral (0.150 to 0.169) but hurt Zephyr (0.109 to 0.039), and chain-of-thought improved neither.",
    "Retrieval-based prompting with TF-IDF example selection is sensitive to how many examples are used: k=2 scored 0.184, dropping to 0.132 at k=8, without beating static few-shot.",
    "Emotions relate to convincingness weakly but systematically. Anger correlates negatively (-0.089 for Mistral zero-shot) while pride and relief show small positive associations, suggesting a rhetorical rather than deterministic role.",
  ] as string[],
};

export const thesisPipeline: Diagram = {
  title: "Experimental pipeline",
  kind: "pipeline",
  nodes: [
    { id: "data", label: "Datasets", detail: "CONTARGA (argumentative text), GoEmotions (Reddit comments) and TweetEval (tweets)." },
    { id: "prep", label: "Preprocessing", detail: "Texts and emotion labels are prepared for fine-tuning and prompting." },
    { id: "models", label: "Model families", detail: "Fine-tuned encoders (RoBERTa, DeBERTa) and instruction-tuned LLMs (Mistral, Zephyr).", tech: ["RoBERTa", "DeBERTa", "Mistral", "Zephyr"] },
    { id: "adapt", label: "Adaptation strategy", detail: "Zero-shot, few-shot, chain-of-thought and retrieval-augmented prompting, plus LoRA fine-tuning.", tech: ["LoRA", "RAG"] },
    { id: "eval", label: "Evaluation", detail: "Macro-F1, precision, recall, per-class scores and confusion matrices." },
    { id: "conv", label: "Convincingness analysis", detail: "Analysing how emotions in arguments relate to how convincing they are." },
  ],
};
