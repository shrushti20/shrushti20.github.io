import type { Maybe } from "@/lib/types";

export const certifications: { name: string; issuer: Maybe<string>; year: Maybe<string>; url: Maybe<string> }[] = [
  { name: "Data Science with Python and Machine Learning", issuer: null, year: null, url: null },
  { name: "Internet of Things", issuer: "ESCA", year: null, url: null },
  { name: "Modern Web Application Development with MEAN Stack", issuer: null, year: null, url: null },
];

export const education = [
  { degree: "M.Sc. International Software Systems Science", school: "Otto-Friedrich-Universität Bamberg", place: "Bamberg, Germany", period: "2022 – 2026" },
  { degree: "B.E. Computer Science and Engineering", school: "Bangalore Institute of Technology", place: "Bangalore, India", period: "2017 – 2021" },
];
