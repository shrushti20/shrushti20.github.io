import type { Job } from "@/lib/types";

export const experience: Job[] = [
  {
    id: "siemens",
    company: "Siemens Healthineers",
    role: "Working Student",
    team: "Hybrid Cloud Integration",
    location: "Germany",
    period: "Aug 2025 – Sep 2026",
    points: [
      "Developed and maintained dashboards for reporting, operational monitoring and workflow visibility across healthcare technology systems.",
      "Supported internal platform work through testing, dashboard improvements and workflow optimisation.",
      "Built integration and automation workflows with SnapLogic across connected systems.",
      "Worked with cross-functional stakeholders on data-driven operational workflows.",
    ],
    tech: ["SnapLogic", "Dashboards", "Integration", "Testing"],
  },
  {
    id: "codebucket",
    company: "Codebucket Solutions",
    role: "Data Scientist Intern",
    location: "Remote",
    period: "Jan 2024 – Sep 2024",
    points: [
      "Built machine learning workflows in Python and SQL for predictive analytics.",
      "Designed Power BI dashboards backed by DAX data models for reporting and decision support.",
      "Optimised Azure cloud infrastructure for performance, scalability and cost.",
      "Worked in Agile sprints across planning, testing, debugging and technical reviews.",
    ],
    tech: ["Python", "SQL", "Power BI", "DAX", "Azure"],
  },
  {
    id: "mindtree",
    company: "Mindtree",
    role: "Software Engineer",
    location: "Bangalore, India",
    period: "Jul 2021 – Aug 2022",
    points: [
      "Developed enterprise applications and analytics workflows with Apache Superset and CVAT for client-facing solutions.",
      "Implemented TensorFlow computer vision workflows for image recognition and classification.",
      "Built dashboards and visual analytics features for business and technical stakeholders.",
      "Contributed frontend improvements, testing and debugging for stakeholder-driven features.",
    ],
    tech: ["TensorFlow", "Computer vision", "Apache Superset", "CVAT"],
  },
];
