"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { site } from "@/config/site";

const links = [
  { href: "/#about", label: "About" },
  { href: "/#experience", label: "Experience" },
  { href: "/projects/", label: "Projects" },
  { href: "/research/", label: "Research" },
  { href: "/building/", label: "Building" },
  { href: "/#contact", label: "Contact" },
];

export function Nav() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-40 border-b border-rule bg-bg/80 backdrop-blur-md">
      <nav aria-label="Main" className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 sm:px-8">
        <Link href="/" className="font-display text-lg font-bold">{site.shortName}</Link>

        <ul className="hidden items-center gap-7 text-sm md:flex">
          {links.map((l) => {
            const active = !l.href.includes("#") && pathname.startsWith(l.href.replace(/\/$/, ""));
            return (
              <li key={l.href}>
                <Link href={l.href} className={`transition-colors hover:text-ink ${active ? "text-ink" : "text-muted"}`}>{l.label}</Link>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-2">
          <a href={site.resumePath} download className="hidden rounded-lg border border-rule px-3 py-1.5 text-sm font-medium hover:border-accent sm:inline-block">
            Resume
          </a>
          <ThemeToggle />
          <button
            className="grid h-9 w-9 place-items-center rounded-lg border border-rule md:hidden"
            aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((o) => !o)}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.ul
            id="mobile-menu"
            initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-rule bg-bg px-5 md:hidden"
          >
            {links.map((l) => (
              <li key={l.href} className="border-b border-rule last:border-0">
                <Link href={l.href} onClick={() => setOpen(false)} className="block py-3.5 text-base">{l.label}</Link>
              </li>
            ))}
            <li className="py-3.5">
              <a href={site.resumePath} download className="text-base font-medium text-accent">Download resume</a>
            </li>
          </motion.ul>
        )}
      </AnimatePresence>
    </header>
  );
}

function ThemeToggle() {
  const [light, setLight] = useState(false);
  useEffect(() => setLight(document.documentElement.classList.contains("light")), []);
  const toggle = () => {
    const next = !light;
    setLight(next);
    document.documentElement.classList.toggle("light", next);
    try { localStorage.setItem("theme", next ? "light" : "dark"); } catch {}
  };
  return (
    <button onClick={toggle} aria-label={light ? "Switch to dark mode" : "Switch to light mode"} className="grid h-9 w-9 place-items-center rounded-lg border border-rule hover:border-accent">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
        {light ? (
          <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
        ) : (
          <>
            <circle cx="12" cy="12" r="4" />
            <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
          </>
        )}
      </svg>
    </button>
  );
}
