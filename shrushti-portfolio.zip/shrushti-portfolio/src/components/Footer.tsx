import { site } from "@/config/site";

export function Footer() {
  return (
    <footer className="border-t border-rule">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-8 text-sm text-muted sm:px-8">
        <p>© {new Date().getFullYear()} {site.name}. Built with Next.js, TypeScript and Tailwind CSS.</p>
        <ul className="flex gap-5">
          <li><a className="hover:text-ink" href={site.github} target="_blank" rel="noopener">GitHub</a></li>
          <li><a className="hover:text-ink" href={site.linkedin} target="_blank" rel="noopener">LinkedIn</a></li>
          <li><a className="hover:text-ink" href={`mailto:${site.email}`}>Email</a></li>
        </ul>
      </div>
    </footer>
  );
}
