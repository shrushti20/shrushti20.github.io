"use client";
import Link from "next/link";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { corpusSize, search, type Hit } from "@/lib/search";

const examples = ["Have you built RAG systems?", "LoRA fine-tuning", "Kubernetes", "Power BI dashboards", "Healthcare"];

function highlight(text: string, terms: string[]) {
  const ts = terms.filter((t) => t.length > 1).map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  if (!ts.length) return text;
  const re = new RegExp(`\\b(?:${ts.join("|")})[a-z]*`, "gi");
  const out: React.ReactNode[] = [];
  let last = 0;
  for (const m of text.matchAll(re)) {
    out.push(text.slice(last, m.index));
    out.push(<mark key={m.index}>{m[0]}</mark>);
    last = (m.index ?? 0) + m[0].length;
  }
  out.push(text.slice(last));
  return out;
}

/** The signature feature: a tiny BM25 retriever over this portfolio. */
export function AskPortfolio() {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<Hit[] | null>(null);
  const run = (query: string) => { setQ(query); setHits(query.trim() ? search(query) : null); };
  const top = hits?.[0]?.score ?? 1;

  return (
    <div className="rounded-2xl border border-rule bg-surface/90 p-5 shadow-[0_20px_60px_-30px_rgba(0,0,0,.5)] backdrop-blur sm:p-6">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-lg font-semibold">Ask this portfolio</h2>
        <span className="hidden font-mono text-[0.7rem] text-faint sm:inline">BM25, in your browser</span>
      </div>
      <p className="mt-1 text-sm text-muted">A small retrieval system over my own work. Try a skill or a question.</p>

      <form className="mt-4 flex gap-2" role="search" onSubmit={(e) => { e.preventDefault(); run(q); }}>
        <label htmlFor="ask" className="sr-only">Search my experience</label>
        <input
          id="ask" type="search" value={q} onChange={(e) => setQ(e.target.value)}
          placeholder="e.g. Have you built RAG systems?"
          className="min-w-0 flex-1 rounded-xl border border-rule bg-bg px-3.5 py-2.5 font-mono text-sm outline-none placeholder:text-faint focus:border-accent"
        />
        <button className="rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink">Search</button>
      </form>

      <div className="mt-3 flex flex-wrap gap-1.5" aria-label="Example searches">
        {examples.map((e) => (
          <button key={e} type="button" onClick={() => run(e)} className="rounded-full bg-surface-2 px-3 py-1 text-xs text-muted hover:text-ink">
            {e}
          </button>
        ))}
      </div>

      <div aria-live="polite">
        <AnimatePresence mode="wait">
          {hits && (
            <motion.div key={q} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4 space-y-2">
              {hits.length === 0 ? (
                <p className="text-sm text-muted">Nothing matches &ldquo;{q}&rdquo;. Try &ldquo;RAG&rdquo;, &ldquo;dashboards&rdquo; or &ldquo;Kubernetes&rdquo;.</p>
              ) : (
                <>
                  {hits.map((h) => (
                    <Link key={h.chunk.id} href={h.chunk.href} className="grid grid-cols-[2.5rem_1fr] gap-3 rounded-xl border border-rule bg-bg/60 p-3 hover:border-accent">
                      <div className="pt-0.5 text-right font-mono text-[0.7rem] text-faint">
                        {(h.score / top).toFixed(2)}
                        <div className="mt-1.5 h-1 overflow-hidden rounded bg-rule">
                          <div className="h-full bg-accent" style={{ width: `${(h.score / top) * 100}%` }} />
                        </div>
                      </div>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-baseline gap-x-2">
                          <span className="text-sm font-semibold">{h.chunk.title}</span>
                          <span className="font-mono text-[0.7rem] text-faint">{h.chunk.kind}</span>
                        </div>
                        <p className="mt-0.5 text-[0.82rem] leading-relaxed text-muted">{highlight(h.snippet, h.terms)}</p>
                      </div>
                    </Link>
                  ))}
                  <p className="font-mono text-[0.7rem] text-faint">Top {hits.length} of {corpusSize()} chunks</p>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
