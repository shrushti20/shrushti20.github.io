import { skills } from "@/data/skills";

export function Skills() {
  return (
    <div className="grid gap-x-12 gap-y-9 sm:grid-cols-2 lg:grid-cols-3">
      {skills.map((g) => (
        <div key={g.group}>
          <h3 className="mb-3 text-sm font-semibold">{g.group}</h3>
          <ul className="flex flex-wrap gap-1.5">
            {g.items.map((s) => (
              <li key={s} className="rounded-md border border-rule bg-surface px-2.5 py-1 text-sm text-muted">{s}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
