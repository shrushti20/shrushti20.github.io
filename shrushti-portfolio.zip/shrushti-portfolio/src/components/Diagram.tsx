"use client";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import type { Diagram as D, DiagramNode } from "@/lib/types";

/** Interactive architecture diagram. Click a node to see what it does, or trace the flow. */
export function Diagram({ diagram, compact = false }: { diagram: D; compact?: boolean }) {
  const [sel, setSel] = useState(0);
  const [playing, setPlaying] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const reduce = useReducedMotion();
  const order = diagram.nodes;

  useEffect(() => {
    if (!playing) return;
    setSel(0);
    let i = 0;
    timer.current = setInterval(() => {
      i += 1;
      if (i >= order.length) { setPlaying(false); return; }
      setSel(i);
    }, reduce ? 1600 : 1100);
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [playing, order.length, reduce]);

  const choose = (i: number) => { setPlaying(false); setSel(i); };
  const node = order[sel];

  return (
    <figure className="rounded-2xl border border-rule bg-surface p-4 sm:p-6">
      <figcaption className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <span className="text-sm font-semibold">{diagram.title}</span>
        <button
          onClick={() => setPlaying((p) => !p)}
          className="inline-flex items-center gap-2 rounded-lg border border-rule px-3 py-1.5 text-xs font-medium hover:border-accent"
        >
          <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden fill="currentColor">
            {playing ? <path d="M1 1h3v8H1zM6 1h3v8H6z" /> : <path d="M1 0l9 5-9 5z" />}
          </svg>
          {playing ? "Pause" : "Trace the flow"}
        </button>
      </figcaption>

      {diagram.kind === "cluster" ? (
        <Cluster diagram={diagram} sel={sel} choose={choose} />
      ) : (
        <Pipeline nodes={order} sel={sel} choose={choose} compact={compact} />
      )}

      <div className="mt-4 min-h-[6.5rem] rounded-xl border border-rule bg-bg/60 p-4" aria-live="polite">
        <AnimatePresence mode="wait">
          <motion.div key={node.id} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-xs text-faint">{String(sel + 1).padStart(2, "0")}/{String(order.length).padStart(2, "0")}</span>
              <span className="font-semibold">{node.label}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{node.detail}</p>
            {node.tech && (
              <ul className="mt-2 flex flex-wrap gap-1.5">
                {node.tech.map((t) => <li key={t} className="rounded-md bg-accent/12 px-2 py-0.5 text-xs text-accent">{t}</li>)}
              </ul>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </figure>
  );
}

function NodeButton({ n, i, active, passed, onClick }: { n: DiagramNode; i: number; active: boolean; passed: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`relative z-10 w-full rounded-xl border px-3 py-2.5 text-left text-sm leading-snug transition-colors ${
        active ? "border-accent bg-accent/10 text-ink" : passed ? "border-accent/40 bg-surface-2 text-ink" : "border-rule bg-surface-2 text-muted hover:text-ink"
      }`}
    >
      <span className="mr-2 font-mono text-[0.68rem] text-faint lg:mr-0 lg:block">{String(i + 1).padStart(2, "0")}</span>
      <span className="font-medium">{n.label}</span>
    </button>
  );
}

function Pipeline({ nodes, sel, choose, compact }: { nodes: DiagramNode[]; sel: number; choose: (i: number) => void; compact: boolean }) {
  return (
    <ol className={`flex flex-col lg:flex-row lg:items-stretch ${compact ? "" : ""}`}>
      {nodes.map((n, i) => (
        <li key={n.id} className="flex flex-col items-stretch lg:min-w-0 lg:flex-1 lg:flex-row lg:items-center">
          <NodeButton n={n} i={i} active={i === sel} passed={i < sel} onClick={() => choose(i)} />
          {i < nodes.length - 1 && <Connector lit={i < sel} />}
        </li>
      ))}
    </ol>
  );
}

function Connector({ lit, vertical = false }: { lit: boolean; vertical?: boolean }) {
  return (
    <span aria-hidden className={`relative mx-auto block ${vertical ? "h-5 w-px" : "h-4 w-px lg:mx-0 lg:h-px lg:w-3 lg:flex-none"} ${lit ? "bg-accent" : "bg-rule"} transition-colors`} />
  );
}

function Cluster({ diagram, sel, choose }: { diagram: D; sel: number; choose: (i: number) => void }) {
  const idx = (id: string) => diagram.nodes.findIndex((n) => n.id === id);
  const grouped = diagram.grouped ?? [];
  const outside = diagram.nodes.filter((n) => !grouped.includes(n.id));
  const entry = grouped[0];
  const store = grouped.length > 2 ? grouped[grouped.length - 1] : undefined;
  const middle = grouped.slice(1, store ? -1 : undefined);
  const btn = (id: string) => {
    const i = idx(id);
    return <NodeButton key={id} n={diagram.nodes[i]} i={i} active={i === sel} passed={i < sel} onClick={() => choose(i)} />;
  };

  return (
    <div className="flex flex-col items-stretch gap-0 lg:flex-row lg:items-center">
      <div className="flex flex-col gap-2">{outside.map((n) => btn(n.id))}</div>
      <Connector lit={sel >= 1} />
      <div className="relative flex-1 rounded-2xl border border-dashed border-faint/60 p-4 pt-7">
        <span className="absolute left-4 top-2 font-mono text-[0.7rem] text-faint">{diagram.groupLabel}</span>
        <div className="flex flex-col items-center">
          {entry && btn(entry)}
          <Connector lit={sel > idx(entry)} vertical />
          <div className="grid w-full grid-cols-1 gap-2 sm:grid-cols-3">{middle.map((id) => btn(id))}</div>
          {store && (
            <>
              <Connector lit={sel >= idx(store)} vertical />
              {btn(store)}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
