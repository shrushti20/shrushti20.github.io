"use client";
import { useState } from "react";
import { site } from "@/config/site";

/**
 * Works without a backend. With `formspreeId` set in src/config/site.ts it posts
 * to Formspree; otherwise it opens the visitor's email app with the message filled in.
 */
export function ContactForm() {
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    if (!site.formspreeId) {
      const subject = encodeURIComponent(`Portfolio enquiry from ${data.get("name")}`);
      const body = encodeURIComponent(`${data.get("message")}\n\n${data.get("name")} (${data.get("email")})`);
      window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
      return;
    }
    setState("sending");
    try {
      const r = await fetch(`https://formspree.io/f/${site.formspreeId}`, { method: "POST", body: data, headers: { Accept: "application/json" } });
      setState(r.ok ? "sent" : "error");
      if (r.ok) (e.target as HTMLFormElement).reset();
    } catch { setState("error"); }
  }

  const field = "mt-1.5 w-full rounded-xl border border-rule bg-surface px-3.5 py-2.5 text-sm outline-none placeholder:text-faint focus:border-accent";

  if (state === "sent") return <p className="rounded-2xl border border-done/40 bg-done/10 p-5 text-sm">Thanks, your message is on its way. I&apos;ll reply by email.</p>;

  return (
    <form onSubmit={onSubmit} className="grid gap-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="text-sm font-medium">Name<input required name="name" autoComplete="name" className={field} /></label>
        <label className="text-sm font-medium">Email<input required type="email" name="email" autoComplete="email" className={field} /></label>
      </div>
      <label className="text-sm font-medium">Message<textarea required name="message" rows={5} className={field} placeholder="Tell me about the role or project" /></label>
      <div className="flex flex-wrap items-center gap-4">
        <button disabled={state === "sending"} className="rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-accent-ink disabled:opacity-60">
          {state === "sending" ? "Sending…" : "Send message"}
        </button>
        {state === "error" && <span className="text-sm text-progress">Something went wrong. Please email me directly.</span>}
      </div>
    </form>
  );
}
