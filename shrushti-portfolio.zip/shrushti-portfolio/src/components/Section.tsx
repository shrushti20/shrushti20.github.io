import Link from "next/link";

export function Section({
  id, title, intro, link, children, className = "",
}: {
  id?: string; title: string; intro?: React.ReactNode; link?: { href: string; label: string };
  children: React.ReactNode; className?: string;
}) {
  return (
    <section id={id} className={`border-t border-rule py-16 sm:py-24 ${className}`}>
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">{title}</h2>
            {intro && <p className="mt-3 text-muted">{intro}</p>}
          </div>
          {link && (
            <Link href={link.href} className="text-sm font-medium text-accent underline-offset-4 hover:underline">
              {link.label}
            </Link>
          )}
        </div>
        {children}
      </div>
    </section>
  );
}

export function Tags({ items, className = "" }: { items: string[]; className?: string }) {
  return (
    <ul className={`flex flex-wrap gap-1.5 ${className}`}>
      {items.map((t) => (
        <li key={t} className="rounded-md border border-rule bg-surface-2/60 px-2 py-0.5 text-xs text-muted">{t}</li>
      ))}
    </ul>
  );
}
