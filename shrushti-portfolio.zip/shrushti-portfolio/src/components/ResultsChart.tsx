/** Horizontal bar chart for verified results. Renders nothing until data exists. */
export function ResultsChart({ rows, metric }: { rows: { label: string; value: number }[]; metric: string }) {
  if (!rows.length) return null;
  const max = Math.max(...rows.map((r) => r.value), 1e-9);
  const sorted = [...rows].sort((a, b) => b.value - a.value);
  return (
    <figure className="rounded-2xl border border-rule bg-surface p-5 sm:p-6">
      <figcaption className="mb-4 text-sm font-semibold">{metric} by approach</figcaption>
      <ul className="space-y-3">
        {sorted.map((r, i) => (
          <li key={r.label} className="grid grid-cols-[minmax(0,9rem)_1fr_3rem] items-center gap-3 text-sm sm:grid-cols-[minmax(0,16rem)_1fr_3rem]">
            <span className="text-muted" title={r.label}>{r.label}</span>
            <span className="h-2.5 overflow-hidden rounded bg-rule">
              <span className={`block h-full rounded ${i === 0 ? "bg-accent" : "bg-faint"}`} style={{ width: `${(r.value / max) * 100}%` }} />
            </span>
            <span className="text-right font-mono">{r.value.toFixed(2)}</span>
          </li>
        ))}
      </ul>
    </figure>
  );
}
