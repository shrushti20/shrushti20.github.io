import type { Project } from "@/lib/types";

/**
 * Abstract cover art per project category. Drawn with the site's own colours,
 * so cards have a visual without stock photography.
 */
export function ProjectVisual({ p, className = "" }: { p: Project; className?: string }) {
  const kind = p.category[0];
  return (
    <div className={`overflow-hidden rounded-xl border border-rule bg-surface-2/60 ${className}`}>
      <svg viewBox="0 0 320 92" className="h-[92px] w-full" role="img" aria-label={`Abstract artwork for ${p.name}`}>
        <g className="transition-opacity duration-300 group-hover:opacity-100" opacity="0.9">
          {kind === "LLM & RAG" && <Rag />}
          {kind === "NLP" && <Nlp />}
          {kind === "Cloud & DevOps" && <Cloud />}
          {kind === "Data" && <Data />}
          {kind === "Systems" && <Systems />}
          {kind === "Mobile & AR" && <Ar />}
        </g>
      </svg>
    </div>
  );
}

const rule = "var(--rule)", accent = "var(--accent)", faint = "var(--faint)", mark = "var(--mark)";

/** Chunks retrieved into an answer. */
function Rag() {
  const chunks = [0, 1, 2, 3, 4, 5, 6, 7];
  return (
    <>
      {chunks.map((i) => (
        <rect key={i} x={14 + (i % 4) * 26} y={16 + Math.floor(i / 4) * 30} width={20} height={22} rx={3}
          fill={i === 2 || i === 5 ? accent : "none"} opacity={i === 2 || i === 5 ? 0.35 : 1} stroke={i === 2 || i === 5 ? accent : rule} />
      ))}
      <path d="M126 46 H196" stroke={accent} strokeWidth="1.5" strokeDasharray="4 4" />
      <circle cx={214} cy={46} r={16} fill="none" stroke={accent} strokeWidth="1.5" />
      <path d="M230 46 H286" stroke={rule} strokeWidth="1.5" />
      <rect x={272} y={30} width={30} height={32} rx={4} fill={mark} opacity="0.25" stroke={mark} />
    </>
  );
}

/** Emotion labels scattered across a spectrum. */
function Nlp() {
  const pts = [[20, 60], [48, 34], [76, 52], [104, 26], [132, 58], [160, 40], [188, 66], [216, 32], [244, 54], [272, 44], [296, 62]];
  return (
    <>
      <path d={`M${pts.map(([x, y]) => `${x} ${y}`).join(" L")}`} fill="none" stroke={rule} strokeWidth="1.5" />
      {pts.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i % 3 === 1 ? 5 : 3} fill={i % 3 === 1 ? accent : faint} opacity={i % 3 === 1 ? 0.9 : 0.6} />
      ))}
      <rect x={96} y={14} width={44} height={14} rx={3} fill={mark} opacity="0.3" />
    </>
  );
}

/** Containers inside a cluster boundary. */
function Cloud() {
  return (
    <>
      <rect x={70} y={10} width={230} height={72} rx={10} fill="none" stroke={faint} strokeDasharray="5 5" opacity="0.7" />
      <rect x={14} y={34} width={36} height={24} rx={4} fill="none" stroke={rule} />
      <path d="M50 46 H70" stroke={rule} strokeWidth="1.5" />
      {[0, 1, 2].map((i) => (
        <rect key={i} x={92 + i * 68} y={30} width={52} height={32} rx={5} fill={i === 1 ? accent : "none"} opacity={i === 1 ? 0.25 : 1} stroke={i === 1 ? accent : rule} />
      ))}
    </>
  );
}

/** Segments in a bar chart. */
function Data() {
  const bars = [26, 44, 62, 38, 74, 50, 30, 58];
  return (
    <>
      <path d="M14 78 H306" stroke={rule} strokeWidth="1.5" />
      {bars.map((h, i) => (
        <rect key={i} x={20 + i * 36} y={78 - h} width={22} height={h} rx={3} fill={i === 4 ? accent : faint} opacity={i === 4 ? 0.85 : 0.4} />
      ))}
    </>
  );
}

/** Memory blocks and a pointer. */
function Systems() {
  return (
    <>
      {Array.from({ length: 12 }).map((_, i) => (
        <rect key={i} x={14 + i * 25} y={34} width={21} height={24} rx={2} fill={i === 4 ? accent : "none"} opacity={i === 4 ? 0.3 : 1} stroke={i === 4 ? accent : rule} />
      ))}
      <path d="M124 70 v-8 M124 62 l-4 5 M124 62 l4 5" stroke={accent} strokeWidth="1.5" fill="none" />
      <path d="M14 22 H306" stroke={rule} strokeDasharray="2 6" />
    </>
  );
}

/** AR markers seen in space. */
function Ar() {
  return (
    <>
      <path d="M40 78 L160 20 L280 78" fill="none" stroke={rule} strokeWidth="1.5" />
      {[[100, 50], [160, 26], [220, 50]].map(([x, y], i) => (
        <g key={i}>
          <rect x={x - 11} y={y - 11} width={22} height={22} rx={3} fill="none" stroke={i === 1 ? accent : faint} />
          <rect x={x - 4} y={y - 4} width={8} height={8} fill={i === 1 ? accent : faint} opacity="0.7" />
        </g>
      ))}
      <circle cx={160} cy={72} r={4} fill={mark} opacity="0.8" />
    </>
  );
}
