"use client";
import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { projects } from "@/data/projects";
import { ProjectCard } from "./ProjectCard";

const cats = ["All", ...Array.from(new Set(projects.flatMap((p) => p.category)))];

export function ProjectExplorer() {
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return projects.filter((p) => {
      const inCat = cat === "All" || p.category.includes(cat as never);
      const hay = `${p.name} ${p.tagline} ${p.problem} ${p.tech.join(" ")}`.toLowerCase();
      return inCat && (!needle || needle.split(/\s+/).every((w) => hay.includes(w)));
    });
  }, [cat, q]);

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          {cats.map((c) => (
            <button
              key={c} onClick={() => setCat(c)} aria-pressed={cat === c}
              className={`relative rounded-full px-3.5 py-1.5 text-sm transition-colors ${cat === c ? "text-accent-ink" : "text-muted hover:text-ink"}`}
            >
              {cat === c && <motion.span layoutId="cat-pill" className="absolute inset-0 rounded-full bg-accent" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
              <span className="relative">{c}</span>
            </button>
          ))}
        </div>
        <label className="relative block lg:w-72">
          <span className="sr-only">Search projects</span>
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>
          <input
            type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or technology"
            className="w-full rounded-xl border border-rule bg-surface py-2.5 pl-9 pr-3 text-sm outline-none placeholder:text-faint focus:border-accent"
          />
        </label>
      </div>

      <motion.div layout className="grid gap-5 md:grid-cols-2">
        <AnimatePresence mode="popLayout">
          {list.map((p) => <ProjectCard key={p.slug} p={p} />)}
        </AnimatePresence>
      </motion.div>
      {list.length === 0 && <p className="py-12 text-center text-muted">No projects match that search.</p>}
    </div>
  );
}
