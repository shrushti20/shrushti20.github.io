"use client";
import { useEffect, useState } from "react";
import { site } from "@/config/site";

interface Repo { name: string; description: string | null; html_url: string; language: string | null; stargazers_count: number; pushed_at: string; fork: boolean }

/** Live list of real public repositories from the GitHub API. Nothing is invented. */
export function GitHubRepos() {
  const [repos, setRepos] = useState<Repo[] | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    fetch(`https://api.github.com/users/${site.githubUsername}/repos?per_page=100&sort=pushed`)
      .then((r) => (r.ok ? r.json() : Promise.reject(r.status)))
      .then((all: Repo[]) => {
        const own = all.filter((r) => !r.fork && r.name.toLowerCase() !== `${site.githubUsername}.github.io`);
        const picked = site.featuredRepos.length
          ? site.featuredRepos.map((n) => own.find((r) => r.name === n)).filter(Boolean) as Repo[]
          : own.slice(0, 6);
        setRepos(picked);
      })
      .catch(() => setFailed(true));
  }, []);

  const profile = (
    <a href={site.github} target="_blank" rel="noopener" className="font-medium text-accent hover:underline">
      View all on GitHub
    </a>
  );

  if (failed) return <p className="text-muted">Couldn&apos;t load repositories right now. {profile}</p>;
  if (!repos)
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true">
        {[0, 1, 2].map((i) => <div key={i} className="h-32 animate-pulse rounded-2xl border border-rule bg-surface" />)}
      </div>
    );
  if (!repos.length) return <p className="text-muted">Public repositories will appear here as they&apos;re published. {profile}</p>;

  return (
    <div>
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {repos.map((r) => (
          <li key={r.name}>
            <a href={r.html_url} target="_blank" rel="noopener" className="flex h-full flex-col rounded-2xl border border-rule bg-surface p-5 transition-colors hover:border-accent/50">
              <span className="font-mono text-sm font-medium">{r.name}</span>
              <span className="mt-2 flex-1 text-sm text-muted">{r.description ?? "No description yet."}</span>
              <span className="mt-4 flex gap-4 text-xs text-faint">
                {r.language && <span>{r.language}</span>}
                {r.stargazers_count > 0 && <span>★ {r.stargazers_count}</span>}
                <span>Updated {new Date(r.pushed_at).toLocaleDateString("en-GB", { month: "short", year: "numeric" })}</span>
              </span>
            </a>
          </li>
        ))}
      </ul>
      <p className="mt-5 text-sm">{profile}</p>
    </div>
  );
}
