/**
 * Subtle technical background: a faint grid plus a sparse node graph where
 * a signal occasionally travels along an edge. Pure CSS animation, disabled
 * for users who prefer reduced motion.
 */
const nodes: [number, number][] = [
  [80, 90], [230, 40], [380, 130], [540, 60], [700, 150], [860, 70], [1020, 140], [1150, 60],
  [150, 250], [320, 300], [480, 240], [640, 320], [800, 260], [960, 330], [1110, 250],
];
const edges: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [0, 8], [8, 9], [9, 10], [2, 10],
  [10, 11], [11, 12], [4, 12], [12, 13], [13, 14], [6, 14], [7, 14],
];

export function HeroBackground() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="grid-bg absolute inset-0 opacity-70" />
      <svg className="absolute inset-x-0 top-6 h-[380px] w-full opacity-60" viewBox="0 0 1200 380" preserveAspectRatio="xMidYMid slice">
        <style>{`
          .edge{stroke:var(--rule);stroke-width:1}
          .pulse{stroke:var(--accent);stroke-width:1.5;stroke-linecap:round;stroke-dasharray:14 400;stroke-dashoffset:414;opacity:0;animation:travel 9s linear infinite}
          .node{fill:var(--bg);stroke:var(--faint);stroke-width:1}
          @keyframes travel{0%{stroke-dashoffset:414;opacity:0}4%{opacity:.9}22%{stroke-dashoffset:0;opacity:.9}26%,100%{stroke-dashoffset:0;opacity:0}}
          @media (prefers-reduced-motion:reduce){.pulse{display:none}}
        `}</style>
        {edges.map(([a, b], i) => (
          <line key={`e${i}`} className="edge" x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]} />
        ))}
        {edges.map(([a, b], i) =>
          i % 3 === 0 ? (
            <line key={`p${i}`} className="pulse" style={{ animationDelay: `${(i * 1.3) % 9}s` }}
              x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]} />
          ) : null,
        )}
        {nodes.map(([x, y], i) => <circle key={i} className="node" cx={x} cy={y} r={3.5} />)}
      </svg>
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-bg" />
    </div>
  );
}
