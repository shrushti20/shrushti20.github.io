import { showTodos } from "@/config/site";

/** Visible in development only. Marks content Shrushti still needs to supply. */
export function Todo({ children, block = false }: { children: React.ReactNode; block?: boolean }) {
  if (!showTodos) return null;
  const Tag = block ? "div" : "span";
  return (
    <Tag
      className={`${block ? "mt-3 flex" : "inline-flex"} items-start gap-2 rounded-md border border-dashed border-todo/60 bg-todo/10 px-2.5 py-1.5 font-mono text-[0.78rem] leading-snug text-todo`}
    >
      <span aria-hidden className="font-semibold">TODO</span>
      <span>{children}</span>
    </Tag>
  );
}
