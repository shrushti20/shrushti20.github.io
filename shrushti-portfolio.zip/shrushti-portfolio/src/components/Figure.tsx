import Image from "next/image";

/** A figure taken from the thesis. Kept on a white card so it stays readable in dark mode. */
export function Figure({ src, alt, caption, width, height, maxWidth }: { src: string; alt: string; caption: string; width: number; height: number; maxWidth?: number }) {
  return (
    <figure className="rounded-2xl border border-rule bg-surface p-3 sm:p-4">
      <div className="overflow-x-auto rounded-xl bg-white p-3">
        <Image src={src} alt={alt} width={width} height={height} className="mx-auto h-auto w-full" style={maxWidth ? { maxWidth } : undefined} />
      </div>
      <figcaption className="mt-3 text-sm text-muted">{caption}</figcaption>
    </figure>
  );
}
