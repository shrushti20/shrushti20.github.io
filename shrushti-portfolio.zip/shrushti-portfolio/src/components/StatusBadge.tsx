import type { Status } from "@/lib/types";

const map: Record<Status, { label: string; cls: string; dot: string }> = {
  completed: { label: "Completed", cls: "text-done border-done/35 bg-done/10", dot: "bg-done" },
  "in-progress": { label: "In progress", cls: "text-progress border-progress/40 bg-progress/10", dot: "bg-progress animate-pulse" },
  planned: { label: "Planned", cls: "text-planned border-planned/40 border-dashed", dot: "bg-planned/70" },
};

export function StatusBadge({ status }: { status: Status }) {
  const s = map[status];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${s.cls}`}>
      <span aria-hidden className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {s.label}
    </span>
  );
}
