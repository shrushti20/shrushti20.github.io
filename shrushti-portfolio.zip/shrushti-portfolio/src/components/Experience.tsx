import { experience } from "@/data/experience";
import { Reveal } from "./Reveal";
import { Tags } from "./Section";

export function Experience() {
  return (
    <ol className="relative">
      {experience.map((j, i) => (
        <li key={j.id} className="grid gap-2 border-b border-rule py-8 first:pt-0 last:border-0 md:grid-cols-[12rem_1fr] md:gap-10">
          <Reveal delay={i * 0.05}>
            <p className="font-mono text-sm text-faint">{j.period}</p>
            <p className="mt-1 text-sm text-faint">{j.location}</p>
          </Reveal>
          <Reveal delay={i * 0.05 + 0.05}>
            <h3 className="font-display text-2xl font-bold">{j.company}</h3>
            <p className="mt-1 font-medium text-accent">{j.role}{j.team ? `, ${j.team}` : ""}</p>
            <ul className="mt-4 max-w-3xl space-y-2 text-muted">
              {j.points.map((pt) => (
                <li key={pt} className="flex gap-3"><span aria-hidden className="mt-2.5 h-1 w-1 flex-none rounded-full bg-faint" />{pt}</li>
              ))}
            </ul>
            <Tags items={j.tech} className="mt-4" />
          </Reveal>
        </li>
      ))}
    </ol>
  );
}
