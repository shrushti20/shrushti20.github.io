"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { caseOrder, type CaseSection, type Project } from "@/lib/types";
import { showTodos } from "@/config/site";
import { Todo } from "./Todo";
import { Diagram } from "./Diagram";

const hasContent = (s?: CaseSection) => !!s && (!!s.body?.length || !!s.points?.length || (showTodos && !!s.todo));

/** Numbered, expandable case study. Empty sections are skipped on the live site. */
export function CaseStudy({ p }: { p: Project }) {
  const sections = caseOrder.filter(({ key }) => hasContent(p.caseStudy[key]) || (key === "architecture" && p.diagram));
  const [open, setOpen] = useState<Set<string>>(new Set(sections.slice(0, 3).map((s) => s.key)));
  const all = open.size === sections.length;
  const toggle = (k: string) => setOpen((o) => { const n = new Set(o); if (n.has(k)) n.delete(k); else n.add(k); return n; });

  if (!sections.length) return <Todo block>Write this case study in src/data/projects.ts.</Todo>;

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button onClick={() => setOpen(all ? new Set() : new Set(sections.map((s) => s.key)))} className="text-sm text-accent hover:underline">
          {all ? "Collapse all" : "Expand all"}
        </button>
      </div>
      <ol className="border-t border-rule">
        {sections.map(({ key, title }) => {
          const s = p.caseStudy[key];
          const n = sections.findIndex((c) => c.key === key) + 1;
          const isOpen = open.has(key);
          return (
            <li key={key} className="border-b border-rule">
              <h3>
                <button
                  onClick={() => toggle(key)} aria-expanded={isOpen}
                  className="flex w-full items-center gap-4 py-5 text-left"
                >
                  <span className="w-8 font-mono text-sm text-faint">{String(n).padStart(2, "0")}</span>
                  <span className="flex-1 font-display text-xl font-semibold">{title}</span>
                  <motion.svg animate={{ rotate: isOpen ? 45 : 0 }} width="16" height="16" viewBox="0 0 16 16" stroke="currentColor" strokeWidth="1.8" className="text-muted" aria-hidden>
                    <path d="M8 2v12M2 8h12" />
                  </motion.svg>
                </button>
              </h3>
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
                    <div className="pb-7 text-muted sm:pl-12">
                      <div className="prose-body max-w-3xl">
                      {s?.body?.map((b, i) => <p key={i}>{b}</p>)}
                      {s?.points && (
                        <ul className="mt-3 space-y-1.5">
                          {s.points.map((pt) => (
                            <li key={pt} className="flex gap-3"><span aria-hidden className="mt-2.5 h-1 w-1 flex-none rounded-full bg-accent" />{pt}</li>
                          ))}
                        </ul>
                      )}
                      </div>
                      {key === "architecture" && p.diagram && <div className="mt-5"><Diagram diagram={p.diagram} /></div>}
                      {s?.todo && <Todo block>{s.todo}</Todo>}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
