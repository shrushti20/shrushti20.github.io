"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import type { Project } from "@/lib/types";
import { StatusBadge } from "./StatusBadge";
import { Todo } from "./Todo";

export const projectHref = (p: Project) => (p.slug === "thesis" ? "/research/" : `/projects/${p.slug}/`);

/** Architecture preview: the first steps of the project's pipeline, or its stack. */
function MiniFlow({ p }: { p: Project }) {
  const steps = p.diagram ? p.diagram.nodes.map((n) => n.label) : p.tech;
  const shown = steps.slice(0, 4);
  return (
    <div className="flex flex-wrap items-center gap-y-1.5 font-mono text-[0.7rem] text-faint" aria-label={p.diagram ? "Architecture preview" : "Stack"}>
      {shown.map((s, i) => (
        <span key={s} className="flex items-center">
          <span className="rounded border border-rule px-1.5 py-0.5 transition-colors group-hover:border-accent/40 group-hover:text-muted">{s}</span>
          {i < shown.length - 1 && <span aria-hidden className={`mx-1 h-px w-3 ${p.diagram ? "bg-faint/60" : "bg-transparent"}`} />}
        </span>
      ))}
      {steps.length > shown.length && <span className="ml-1.5">+{steps.length - shown.length}</span>}
    </div>
  );
}

export function ProjectCard({ p, large = false }: { p: Project; large?: boolean }) {
  const href = projectHref(p);
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.98 }}
      whileHover={{ y: -3 }}
      transition={{ duration: 0.25 }}
      className="group relative flex h-full flex-col rounded-2xl border border-rule bg-surface p-5 transition-colors hover:border-accent/50 sm:p-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <StatusBadge status={p.status} />
        {p.period && <span className="font-mono text-xs text-faint">{p.period}</span>}
      </div>

      <h3 className={`mt-4 font-display font-bold leading-tight ${large ? "text-2xl sm:text-3xl" : "text-xl"}`}>
        <Link href={href} className="after:absolute after:inset-0 after:rounded-2xl">{p.name}</Link>
      </h3>
      <p className="mt-2 text-muted">{p.tagline}</p>

      <div className="mt-4 rounded-xl bg-surface-2/70 p-3 text-sm">
        <span className="font-medium text-ink">Problem. </span>
        <span className="text-muted">{p.problem}</span>
      </div>

      {p.highlight && (
        <div className="mt-4 flex items-baseline gap-3">
          <span className="font-display text-3xl font-bold text-ink">{p.highlight.value}</span>
          <span className="text-sm text-muted">{p.highlight.label}</span>
        </div>
      )}

      {p.diagram && <div className="mt-4"><MiniFlow p={p} /></div>}

      <ul className="mt-4 flex flex-wrap gap-1.5">
        {p.tech.slice(0, large ? 8 : 5).map((t) => (
          <li key={t} className="rounded-md border border-rule px-2 py-0.5 text-xs text-muted">{t}</li>
        ))}
      </ul>

      <div className="relative z-10 mt-auto flex flex-wrap items-center gap-2 pt-5 text-sm">
        <Link href={href} className="rounded-lg bg-accent px-3.5 py-2 font-semibold text-accent-ink">
          {p.slug === "thesis" ? "Read the research" : "Case study"}
        </Link>
        {p.links.github ? (
          <a href={p.links.github} target="_blank" rel="noopener" className="rounded-lg border border-rule px-3.5 py-2 font-medium hover:border-accent">GitHub</a>
        ) : (
          <Todo>GitHub link</Todo>
        )}
        {p.links.demo && (
          <a href={p.links.demo} target="_blank" rel="noopener" className="rounded-lg border border-rule px-3.5 py-2 font-medium hover:border-accent">Live demo</a>
        )}
      </div>
    </motion.article>
  );
}
