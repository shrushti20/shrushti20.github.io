"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { BuildItem } from "@/lib/types";
import { StatusBadge } from "./StatusBadge";
import { Diagram } from "./Diagram";

export function BuildingCard({ b }: { b: BuildItem }) {
  const [open, setOpen] = useState(false);
  const done = b.milestones.filter((m) => m.done).length;
  const pct = Math.round((done / b.milestones.length) * 100);

  return (
    <article id={b.slug} className="scroll-mt-24 rounded-2xl border border-dashed border-rule bg-surface/50 p-5 sm:p-7">
      <div className="flex flex-wrap items-center gap-3">
        <span className="grid h-8 w-8 place-items-center rounded-lg border border-rule font-mono text-sm text-muted">{b.code}</span>
        <StatusBadge status={b.status} />
        <span className="text-xs text-faint">Not yet complete</span>
      </div>
      <h3 className="mt-4 font-display text-2xl font-bold">{b.name}</h3>
      <p className="mt-2 max-w-3xl text-muted">{b.pitch}</p>

      <div className="mt-5 grid gap-6 md:grid-cols-[1fr_16rem]">
        <div>
          <h4 className="text-sm font-semibold">Why this project</h4>
          <p className="mt-1 text-sm text-muted">{b.why}</p>
          <h4 className="mt-5 text-sm font-semibold">Planned scope</h4>
          <ul className="mt-2 flex flex-wrap gap-1.5">
            {b.scope.map((s) => <li key={s} className="rounded-md border border-dashed border-rule px-2 py-0.5 text-xs text-muted">{s}</li>)}
          </ul>
          <h4 className="mt-5 text-sm font-semibold">Planned stack</h4>
          <p className="mt-1 text-sm text-muted">{b.stack.join(", ")}</p>
        </div>

        <div>
          <div className="flex items-baseline justify-between">
            <h4 className="text-sm font-semibold">Roadmap</h4>
            <span className="font-mono text-xs text-faint">{done}/{b.milestones.length}</span>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded bg-rule"><div className="h-full bg-progress" style={{ width: `${pct}%` }} /></div>
          <ul className="mt-3 space-y-2 text-sm">
            {b.milestones.map((m) => (
              <li key={m.label} className={`flex gap-2.5 ${m.done ? "text-ink" : "text-muted"}`}>
                <span aria-hidden className={`mt-1 grid h-3.5 w-3.5 flex-none place-items-center rounded-sm border ${m.done ? "border-done bg-done/20" : "border-faint"}`}>
                  {m.done && <svg width="8" height="8" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1.5 5.5l2.5 2.5 4.5-6" /></svg>}
                </span>
                <span>{m.label}<span className="sr-only">{m.done ? " (done)" : " (not started)"}</span></span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <button onClick={() => setOpen((o) => !o)} aria-expanded={open} className="rounded-lg border border-rule px-3.5 py-2 text-sm font-medium hover:border-accent">
          {open ? "Hide architecture" : "Show planned architecture"}
        </button>
        {b.repo && <a href={b.repo} target="_blank" rel="noopener" className="rounded-lg border border-rule px-3.5 py-2 text-sm font-medium hover:border-accent">Follow on GitHub</a>}
      </div>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="pt-5"><Diagram diagram={b.diagram} /></div>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  );
}
