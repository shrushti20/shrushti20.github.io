export type Status = "completed" | "in-progress" | "planned";

/** A text value that may be missing. `null` renders as a TODO placeholder. */
export type Maybe<T> = T | null;

export interface DiagramNode {
  id: string;
  label: string;
  /** Shown when the node is selected. */
  detail: string;
  tech?: string[];
}

export interface Diagram {
  title: string;
  kind: "pipeline" | "cluster";
  nodes: DiagramNode[];
  /** Cluster diagrams: which node ids sit inside the boundary box. */
  groupLabel?: string;
  grouped?: string[];
}

export interface CaseSection {
  /** Paragraphs of verified content. */
  body?: string[];
  /** Bullet points of verified content. */
  points?: string[];
  /** What the author still needs to supply. Rendered as a TODO chip. */
  todo?: string;
}

export interface Project {
  slug: string;
  name: string;
  tagline: string;
  problem: string;
  status: Status;
  hero?: boolean;
  period?: string;
  category: ("LLM & RAG" | "NLP" | "ML" | "Data" | "Cloud & DevOps" | "Systems" | "Mobile & AR")[];
  tech: string[];
  highlight?: { value: string; label: string };
  links: { github: Maybe<string>; demo?: Maybe<string>; paper?: Maybe<string> };
  diagram?: Diagram;
  caseStudy: Partial<Record<CaseKey, CaseSection>>;
}

export type CaseKey =
  | "problem"
  | "why"
  | "architecture"
  | "tech"
  | "implementation"
  | "challenges"
  | "evaluation"
  | "results"
  | "learned"
  | "future";

export const caseOrder: { key: CaseKey; title: string }[] = [
  { key: "problem", title: "Problem" },
  { key: "why", title: "Why it matters" },
  { key: "architecture", title: "Architecture" },
  { key: "tech", title: "Technology choices" },
  { key: "implementation", title: "Implementation" },
  { key: "challenges", title: "Challenges" },
  { key: "evaluation", title: "Evaluation" },
  { key: "results", title: "Results" },
  { key: "learned", title: "What I learned" },
  { key: "future", title: "Future improvements" },
];

export interface Job {
  id: string;
  company: string;
  role: string;
  team?: string;
  location: string;
  period: string;
  points: string[];
  tech: string[];
}

export interface BuildItem {
  slug: string;
  code: string;
  name: string;
  status: Exclude<Status, "completed">;
  pitch: string;
  why: string;
  scope: string[];
  stack: string[];
  milestones: { label: string; done: boolean }[];
  diagram: Diagram;
  repo: Maybe<string>;
}
