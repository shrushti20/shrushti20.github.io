import { experience } from "@/data/experience";
import { projects } from "@/data/projects";
import { skills } from "@/data/skills";
import { thesis } from "@/data/research";

/**
 * "Ask this portfolio": a small BM25 retriever over the site's own content.
 * Runs entirely in the browser. Add keywords in `extra` to improve matching.
 */
export interface Chunk { id: string; title: string; kind: string; href: string; text: string }
export interface Hit { chunk: Chunk; score: number; snippet: string; terms: string[] }

const extra: Record<string, string> = {
  "exp-siemens": "healthcare medical enterprise integration automation",
  "proj-codereview-genie": "rag retrieval llm question answering embeddings vector database semantic search",
  "proj-thesis": "nlp research emotion argument transformers fine-tuning lora prompting llm",
  thesis: "nlp research emotion argument transformers fine-tuning lora prompting llm rag",
  "proj-microservices-beverage-system": "devops containers k8s distributed cloud",
  "exp-codebucket": "ml machine learning bi business intelligence cloud analytics",
  "exp-mindtree": "cv vision images deep learning analytics",
};

const synonyms: Record<string, string[]> = {
  rag: ["retrieval"], retrieval: ["rag"], llm: ["llms", "language"], llms: ["llm"],
  k8s: ["kubernetes"], kubernetes: ["k8s"], ml: ["machine", "learning"], cv: ["vision"],
  finetuning: ["fine", "lora"], dashboard: ["dashboards"], dashboards: ["dashboard"], agents: ["agent"],
};

const stop = new Set(
  "a an the and or of to in on for with have has had you your do did does is are was were be been i me my what which how any about can could would it this that there at by from as experience worked work built system systems using use used know".split(" "),
);

export const tokenize = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9+#\-\s]/g, " ").split(/\s+/).filter((w) => w && !stop.has(w));

function buildCorpus(): Chunk[] {
  const c: Chunk[] = [];
  for (const j of experience)
    c.push({ id: `exp-${j.id}`, title: `${j.company}, ${j.role}`, kind: "Experience", href: `/#experience`, text: `${j.role} ${j.team ?? ""}. ${j.points.join(" ")} ${j.tech.join(", ")}.` });
  for (const p of projects)
    c.push({ id: `proj-${p.slug}`, title: p.name, kind: "Project", href: p.slug === "thesis" ? "/research/" : `/projects/${p.slug}/`, text: [
      p.tagline, p.problem, `Built with ${p.tech.join(", ")}.`,
      p.highlight ? `${p.highlight.value} ${p.highlight.label}.` : "",
      ...Object.values(p.caseStudy).flatMap((c) => [...(c?.body ?? []), ...(c?.points ?? [])]),
    ].join(" ") });
  c.push({ id: "thesis", title: "Master's thesis", kind: "Research", href: "/research/", text: `${thesis.title}: ${thesis.subtitle}. ${thesis.approaches.map((a) => `${a.name}: ${a.detail}`).join(" ")} Datasets: ${thesis.datasets.map((d) => d.name).join(", ")}.` });
  for (const s of skills) c.push({ id: `skill-${s.group}`, title: s.group, kind: "Skills", href: "/#skills", text: `${s.items.join(", ")}.` });
  return c;
}

let index: { chunks: Chunk[]; toks: string[][]; df: Record<string, number>; avg: number } | null = null;

function getIndex() {
  if (index) return index;
  const chunks = buildCorpus();
  const toks = chunks.map((ch) => tokenize(`${ch.title} ${ch.text} ${extra[ch.id] ?? ""}`));
  const df: Record<string, number> = {};
  toks.forEach((t) => new Set(t).forEach((w) => (df[w] = (df[w] ?? 0) + 1)));
  const avg = toks.reduce((a, t) => a + t.length, 0) / toks.length;
  index = { chunks, toks, df, avg };
  return index;
}

export const corpusSize = () => getIndex().chunks.length;

export function search(query: string, k = 3): Hit[] {
  const { chunks, toks, df, avg } = getIndex();
  const N = chunks.length;
  let terms = tokenize(query);
  terms = [...new Set(terms.concat(...terms.map((t) => synonyms[t] ?? [])))];
  if (!terms.length) return [];
  const idf = (t: string) => Math.log(1 + (N - (df[t] ?? 0) + 0.5) / ((df[t] ?? 0) + 0.5));
  const k1 = 1.4, b = 0.75;
  return chunks
    .map((chunk, i) => {
      const d = toks[i];
      let score = 0;
      for (const t of terms) {
        const f = d.filter((x) => x === t || (t.length > 3 && x.startsWith(t))).length;
        if (f) score += (idf(t) * f * (k1 + 1)) / (f + k1 * (1 - b + (b * d.length) / avg));
      }
      return { chunk, score, terms, snippet: pickSentence(chunk.text, terms) };
    })
    .filter((h) => h.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, k);
}

function pickSentence(text: string, terms: string[]) {
  const sents = text.split(/(?<=[.!?])\s+/);
  const best = sents
    .map((s) => ({ s, n: terms.filter((t) => s.toLowerCase().includes(t)).length }))
    .sort((a, b) => b.n - a.n)[0];
  const out = best && best.n ? best.s : sents.slice(0, 2).join(" ");
  return out.length > 220 ? out.slice(0, 217) + "…" : out;
}
