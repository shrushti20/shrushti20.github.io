/**
 * Central site configuration. Edit links here once and they update everywhere.
 * Anything set to "" is treated as missing: its button is hidden on the live
 * site and flagged as a TODO in development.
 */
export const site = {
  name: "Shrushti Narayanaswamy",
  shortName: "Shrushti N.",
  headline: "AI / ML Engineer — LLM Agents · RAG Systems · NLP",
  location: "Bamberg, Germany",
  url: "https://shrushti20.github.io",
  email: "shrushtinarayanaswamy@gmail.com",
  linkedin: "https://www.linkedin.com/in/shrushtinarayanaswamy",
  github: "https://github.com/shrushti20",
  githubUsername: "shrushti20",
  resumePath: "/resume.pdf",

  /**
   * Contact form: create a free form at https://formspree.io and paste the
   * form ID (the part after /f/). Empty = the form opens the visitor's email app.
   */
  formspreeId: "",

  /**
   * Repositories to show in the GitHub section, by repo name, in order.
   * Empty = show your most recently updated public repos.
   */
  featuredRepos: [] as string[],

  seo: {
    title: "Shrushti Narayanaswamy | AI/ML Engineer | LLM & RAG Systems",
    description:
      "AI/ML Engineer building LLM applications, RAG systems, NLP pipelines, machine learning systems and cloud-native software.",
  },
};

/**
 * Placeholders like [ADD VERIFIED METRIC] are visible in `npm run dev` and
 * hidden in the production build. Set NEXT_PUBLIC_SHOW_TODOS=true to force
 * them on in a build (e.g. to review a preview deployment).
 */
export const showTodos =
  process.env.NODE_ENV === "development" ||
  process.env.NEXT_PUBLIC_SHOW_TODOS === "true";
