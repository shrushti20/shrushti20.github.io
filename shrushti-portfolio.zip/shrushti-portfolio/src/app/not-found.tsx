import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-3xl px-5 py-32 text-center">
      <p className="font-mono text-sm text-faint">404</p>
      <h1 className="mt-3 font-display text-4xl font-extrabold">Nothing retrieved for this page.</h1>
      <p className="mt-4 text-muted">The page you&apos;re looking for doesn&apos;t exist.</p>
      <Link href="/" className="mt-8 inline-block rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-accent-ink">Back to home</Link>
    </div>
  );
}
