import type { Metadata, Viewport } from "next";
import "./globals.css";
import { site } from "@/config/site";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: site.seo.title, template: `%s | ${site.name}` },
  description: site.seo.description,
  authors: [{ name: site.name, url: site.url }],
  keywords: ["AI Engineer", "ML Engineer", "LLM", "RAG", "NLP", "Machine Learning", "FastAPI", "Kubernetes", "Bamberg", "Germany"],
  alternates: { canonical: "/" },
  icons: { icon: "/favicon.svg" },
  openGraph: {
    type: "website", url: site.url, siteName: site.name,
    title: site.seo.title, description: site.seo.description,
    images: [{ url: "/og-image.png", width: 1200, height: 627, alt: site.name }],
  },
  twitter: { card: "summary_large_image", title: site.seo.title, description: site.seo.description, images: ["/og-image.png"] },
};

export const viewport: Viewport = {
  themeColor: [{ media: "(prefers-color-scheme: dark)", color: "#0e1117" }, { media: "(prefers-color-scheme: light)", color: "#fafaf7" }],
};

const personLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: site.name,
  jobTitle: "AI / ML Engineer",
  url: site.url,
  email: `mailto:${site.email}`,
  address: { "@type": "PostalAddress", addressLocality: "Bamberg", addressCountry: "DE" },
  alumniOf: [{ "@type": "CollegeOrUniversity", name: "Otto-Friedrich-Universität Bamberg" }, { "@type": "CollegeOrUniversity", name: "Bangalore Institute of Technology" }],
  knowsAbout: ["Large Language Models", "Retrieval-Augmented Generation", "Natural Language Processing", "Machine Learning", "Kubernetes"],
  sameAs: [site.linkedin, site.github],
};

// Dark by default; a saved choice wins. Runs before paint to avoid a flash.
const themeScript = `try{if(localStorage.getItem('theme')==='light')document.documentElement.classList.add('light')}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Geist:wght@400..700&family=Geist+Mono:wght@400;500&display=swap" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(personLd) }} />
      </head>
      <body className="min-h-screen">
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-accent focus:px-4 focus:py-2 focus:text-accent-ink">Skip to content</a>
        <Nav />
        <main id="main">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
