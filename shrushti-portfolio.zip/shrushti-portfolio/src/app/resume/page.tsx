import type { Metadata } from "next";
import { site } from "@/config/site";

export const metadata: Metadata = { title: "Resume", description: `Resume of ${site.name}.`, alternates: { canonical: "/resume/" } };

export default function ResumePage() {
  return (
    <div className="mx-auto max-w-5xl px-5 py-14 sm:px-8 sm:py-20">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-display text-4xl font-extrabold sm:text-5xl">Resume</h1>
        <a href={site.resumePath} download className="rounded-xl bg-accent px-4 py-2.5 text-sm font-semibold text-accent-ink">Download PDF</a>
      </div>
      <object data={site.resumePath} type="application/pdf" className="mt-10 h-[80vh] w-full rounded-2xl border border-rule bg-surface">
        <p className="p-6 text-muted">
          Your browser can&apos;t display the PDF here. <a href={site.resumePath} className="text-accent hover:underline">Open the resume</a> instead.
        </p>
      </object>
    </div>
  );
}
