import type { Metadata } from "next";
import { thesis, thesisPipeline } from "@/data/research";
import { Diagram } from "@/components/Diagram";
import { ResultsChart } from "@/components/ResultsChart";
import { Tags } from "@/components/Section";
import { Todo } from "@/components/Todo";
import { showTodos } from "@/config/site";

export const metadata: Metadata = {
  title: "Research: Emotion Recognition in Argumentative Text",
  description: "Master's thesis on transfer learning, prompting and domain adaptation for emotion recognition in argumentative text, comparing RoBERTa, DeBERTa, Mistral and Zephyr.",
  alternates: { canonical: "/research/" },
};

function Block({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <section className="grid gap-3 border-t border-rule py-10 md:grid-cols-[12rem_1fr] md:gap-10">
      <h2 className="flex items-baseline gap-3 font-display text-xl font-semibold">
        <span className="font-mono text-sm font-normal text-faint">{n}</span>{title}
      </h2>
      <div className="min-w-0 text-muted">{children}</div>
    </section>
  );
}

export default function ResearchPage() {
  const t = thesis;
  const link = "rounded-xl border border-rule px-4 py-2.5 text-sm font-semibold hover:border-accent";
  const hasResults = t.results.rows.length > 0;
  const hasFindings = t.findings.length > 0;
  let n = 0;
  const num = () => String(++n).padStart(2, "0");

  return (
    <article className="mx-auto max-w-5xl px-5 py-12 sm:px-8 sm:py-16">
      <p className="text-sm text-muted">Master&apos;s thesis, {t.institution}</p>
      <h1 className="mt-4 font-display text-4xl font-extrabold leading-tight sm:text-5xl">{t.title}</h1>
      <p className="mt-3 text-xl text-muted">{t.subtitle}</p>
      <dl className="mt-8 grid gap-4 text-sm sm:grid-cols-3">
        <div><dt className="text-faint">Degree</dt><dd className="mt-0.5">{t.degree}</dd></div>
        <div><dt className="text-faint">Period</dt><dd className="mt-0.5">{t.period}</dd></div>
        <div><dt className="text-faint">Supervisors</dt><dd className="mt-0.5">{t.supervisors.join(", ")}</dd></div>
      </dl>
      <div className="mt-8 flex flex-wrap items-center gap-3">
        {t.links.pdf ? <a href={t.links.pdf} className={link}>Read the thesis</a> : <Todo>Thesis PDF link</Todo>}
        {t.links.github && <a href={t.links.github} target="_blank" rel="noopener" className={link}>Code on GitHub</a>}
        {t.links.linkedin && <a href={t.links.linkedin} target="_blank" rel="noopener" className={link}>LinkedIn series</a>}
      </div>

      <div className="mt-14">
        <Block n={num()} title="Research questions">
          <ol className="space-y-5">
            {t.questions.map((q) => (
              <li key={q.id}>
                <p className="font-mono text-sm text-accent">{q.id}</p>
                <p className="mt-0.5 font-semibold text-ink">{q.title}</p>
                <p className="mt-1">{q.text}</p>
              </li>
            ))}
          </ol>
        </Block>

        <Block n={num()} title="Problem">
          {t.problem.map((p) => <p key={p}>{p}</p>)}
        </Block>

        <Block n={num()} title="Datasets">
          <ul className="divide-y divide-rule rounded-2xl border border-rule">
            {t.datasets.map((d) => (
              <li key={d.name} className="p-4">
                <p className="font-mono text-sm font-medium text-ink">{d.name}</p>
                <p className="mt-0.5 text-sm">{d.role}</p>
                <Todo block>{d.todo}</Todo>
              </li>
            ))}
          </ul>
        </Block>

        <Block n={num()} title="Methodology">
          <ul className="grid gap-3 sm:grid-cols-2">
            {t.approaches.map((a) => (
              <li key={a.name} className="rounded-2xl border border-rule bg-surface p-4">
                <p className="font-semibold text-ink">{a.name}</p>
                <p className="mt-1 text-sm">{a.detail}</p>
                <Tags items={a.models} className="mt-3" />
              </li>
            ))}
          </ul>
          <Todo block>{t.approachesTodo}</Todo>
        </Block>

        <Block n={num()} title="Experimental pipeline">
          <Diagram diagram={thesisPipeline} />
        </Block>

        <Block n={num()} title="Evaluation">
          <p>Models were compared with:</p>
          <Tags items={t.metrics} className="mt-3" />
        </Block>

        {(hasResults || showTodos) && (
          <Block n={num()} title="Results">
            {hasResults ? (
              <>
                <ResultsChart rows={t.results.rows} metric={t.results.metric} />
                <p className="mt-3 text-sm">Macro-F1 across supervised transfer settings and LLM prompting strategies. In-domain scores are shown for reference; every other row is measured on CONTARGA, the argumentative dataset.</p>
              </>
            ) : <Todo block>Add verified Macro-F1 scores to results.rows in src/data/research.ts. The chart appears automatically.</Todo>}
          </Block>
        )}

        {(hasFindings || showTodos) && (
          <Block n={num()} title="Key findings">
            {hasFindings ? (
              <ol className="space-y-3">
                {t.findings.map((f, i) => (
                  <li key={f} className="flex gap-3"><span className="font-mono text-sm text-accent">{i + 1}</span><span className="text-ink">{f}</span></li>
                ))}
              </ol>
            ) : <Todo block>Add 3–5 key findings to findings in src/data/research.ts.</Todo>}
          </Block>
        )}
      </div>
    </article>
  );
}
