import type { Metadata } from "next";
import { ProjectExplorer } from "@/components/ProjectExplorer";

export const metadata: Metadata = {
  title: "Projects",
  description: "Completed projects in LLM and RAG systems, NLP research, cloud and DevOps, data analytics and systems programming.",
  alternates: { canonical: "/projects/" },
};

export default function ProjectsPage() {
  return (
    <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-20">
      <h1 className="font-display text-4xl font-extrabold sm:text-5xl">Projects</h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        Completed work, each with a case study covering the problem, architecture, decisions and results. Work that isn&apos;t finished yet lives under{" "}
        <a href="/building/" className="text-accent hover:underline">Currently building</a>.
      </p>
      <div className="mt-12"><ProjectExplorer /></div>
    </div>
  );
}
