import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getProject, projects } from "@/data/projects";
import { CaseStudy } from "@/components/CaseStudy";
import { StatusBadge } from "@/components/StatusBadge";
import { Tags } from "@/components/Section";
import { Todo } from "@/components/Todo";

// The thesis has its own page at /research.
const caseStudies = projects.filter((p) => p.slug !== "thesis");

export function generateStaticParams() {
  return caseStudies.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = getProject((await params).slug);
  if (!p) return {};
  return { title: p.name, description: p.tagline, alternates: { canonical: `/projects/${p.slug}/` } };
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = getProject((await params).slug);
  if (!p || p.slug === "thesis") notFound();
  const i = caseStudies.findIndex((x) => x.slug === p.slug);
  const next = caseStudies[(i + 1) % caseStudies.length];
  const link = "rounded-xl border border-rule px-4 py-2.5 text-sm font-semibold hover:border-accent";

  return (
    <article className="mx-auto max-w-5xl px-5 py-12 sm:px-8 sm:py-16">
      <Link href="/projects/" className="text-sm text-muted hover:text-ink">All projects</Link>

      <header className="mt-6">
        <div className="flex flex-wrap items-center gap-3">
          <StatusBadge status={p.status} />
          {p.period && <span className="font-mono text-sm text-faint">{p.period}</span>}
          <span className="text-sm text-faint">{p.category.join(", ")}</span>
        </div>
        <h1 className="mt-4 font-display text-4xl font-extrabold leading-tight sm:text-5xl">{p.name}</h1>
        <p className="mt-4 max-w-3xl text-xl text-muted">{p.tagline}</p>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          {p.links.github ? <a href={p.links.github} target="_blank" rel="noopener" className={link}>GitHub repository</a> : <Todo>GitHub link</Todo>}
          {p.links.demo && <a href={p.links.demo} target="_blank" rel="noopener" className={link}>Live demo</a>}
          {p.links.paper && <a href={p.links.paper} target="_blank" rel="noopener" className={link}>Paper</a>}
        </div>

        <div className="mt-8 grid gap-6 rounded-2xl border border-rule bg-surface p-6 sm:grid-cols-[1fr_auto]">
          <div>
            <h2 className="text-sm font-semibold">Stack</h2>
            <Tags items={p.tech} className="mt-3" />
          </div>
          {p.highlight && (
            <div className="sm:border-l sm:border-rule sm:pl-6">
              <p className="font-display text-4xl font-bold">{p.highlight.value}</p>
              <p className="mt-1 max-w-[14rem] text-sm text-muted">{p.highlight.label}</p>
            </div>
          )}
        </div>
      </header>

      <section className="mt-14" aria-label="Case study">
        <CaseStudy p={p} />
      </section>

      <nav className="mt-16 border-t border-rule pt-8" aria-label="Next project">
        <p className="text-sm text-faint">Next project</p>
        <Link href={`/projects/${next.slug}/`} className="mt-1 inline-block font-display text-2xl font-bold hover:text-accent">{next.name}</Link>
      </nav>
    </article>
  );
}
