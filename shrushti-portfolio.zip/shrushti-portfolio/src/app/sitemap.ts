import type { MetadataRoute } from "next";
import { site } from "@/config/site";
import { projects } from "@/data/projects";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const paths = ["/", "/projects/", "/research/", "/building/", "/resume/", ...projects.filter((p) => p.slug !== "thesis").map((p) => `/projects/${p.slug}/`)];
  return paths.map((p) => ({ url: `${site.url}${p}` }));
}
