import Image from "next/image";
import Link from "next/link";
import { site } from "@/config/site";
import { projects } from "@/data/projects";
import { building } from "@/data/building";
import { certifications, education } from "@/data/certifications";
import { HeroBackground } from "@/components/HeroBackground";
import { AskPortfolio } from "@/components/AskPortfolio";
import { Section } from "@/components/Section";
import { ProjectCard } from "@/components/ProjectCard";
import { Diagram } from "@/components/Diagram";
import { Experience } from "@/components/Experience";
import { Skills } from "@/components/Skills";
import { StatusBadge } from "@/components/StatusBadge";
import { GitHubRepos } from "@/components/GitHubRepos";
import { ContactForm } from "@/components/ContactForm";
import { Reveal } from "@/components/Reveal";
import { Todo } from "@/components/Todo";

const btn = "inline-flex items-center rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors";

export default function Home() {
  const heroes = projects.filter((p) => p.hero);
  const genie = heroes[0];

  return (
    <>
      {/* ---------- Hero ---------- */}
      <section className="relative isolate overflow-hidden">
        <HeroBackground />
        <div className="relative mx-auto grid max-w-6xl gap-12 px-5 pb-16 pt-14 sm:px-8 sm:pt-20 lg:grid-cols-[1.15fr_1fr] lg:items-center lg:pb-24">
          <Reveal>
            <div className="flex items-center gap-4">
              <Image src="/headshot.jpg" alt={`Portrait of ${site.name}`} width={64} height={64} priority className="h-16 w-16 rounded-full border border-rule object-cover object-top" />
              <div>
                <p className="font-semibold">{site.name}</p>
                <p className="text-sm text-muted">{site.headline}</p>
              </div>
            </div>
            <h1 className="mt-8 font-display text-4xl font-extrabold leading-[1.04] sm:text-5xl lg:text-[3.6rem]">
              Building intelligent systems that connect AI, data and software.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted">
              AI/ML Engineer focused on LLM applications, RAG systems, NLP, data engineering and production-oriented software.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/projects/" className={`${btn} bg-accent text-accent-ink`}>View projects</Link>
              <a href={site.github} target="_blank" rel="noopener" className={`${btn} border border-rule hover:border-accent`}>GitHub</a>
              <a href={site.linkedin} target="_blank" rel="noopener" className={`${btn} border border-rule hover:border-accent`}>LinkedIn</a>
              <a href={site.resumePath} download className={`${btn} border border-rule hover:border-accent`}>Download resume</a>
            </div>
          </Reveal>
          <Reveal delay={0.15}><AskPortfolio /></Reveal>
        </div>

        {/* At a glance */}
        <div className="relative mx-auto max-w-6xl px-5 pb-6 sm:px-8">
          <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-rule bg-rule lg:grid-cols-4">
            {[
              ["Looking for", "AI / ML and software engineering roles"],
              ["Most recent", "Siemens Healthineers, until Sep 2026"],
              ["Education", "M.Sc. Software Systems Science, 2026"],
              ["Based in", "Bamberg, Germany"],
            ].map(([k, v]) => (
              <div key={k} className="bg-bg p-4 sm:p-5">
                <dt className="text-xs text-faint">{k}</dt>
                <dd className="mt-1 text-sm font-medium sm:text-base">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* ---------- Featured work ---------- */}
      <Section id="work" title="Featured work" intro="Two projects that show how I work: a RAG system I built end to end, and my Master's research on LLMs and transfer learning." link={{ href: "/projects/", label: `All ${projects.length} projects` }}>
        <div className="grid gap-5 lg:grid-cols-2">
          {heroes.map((p) => <ProjectCard key={p.slug} p={p} large />)}
        </div>
        {genie?.diagram && (
          <Reveal className="mt-6">
            <Diagram diagram={genie.diagram} />
          </Reveal>
        )}
      </Section>

      {/* ---------- About ---------- */}
      <Section id="about" title="About">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          <Reveal className="space-y-4 text-lg text-muted">
            <p>
              I&apos;m a software engineer with an M.Sc. in International Software Systems Science from the University of Bamberg. I work where AI, data and software meet: retrieval-augmented generation, NLP and the engineering needed to run these systems reliably.
            </p>
            <p>
              My experience spans healthcare technology at Siemens Healthineers, data science at Codebucket Solutions and enterprise software at Mindtree. Along the way I&apos;ve built dashboards and data models, automation workflows, computer vision pipelines and cloud infrastructure, which is why I care about the whole system, not just the model.
            </p>
            <p>
              My Master&apos;s thesis compared fine-tuned transformers with prompted and LoRA-adapted LLMs for emotion recognition in argumentative text. Right now I&apos;m focused on production RAG, LLM agents and evaluation.
            </p>
            <Todo block>Add one personal sentence: what draws you to AI engineering, or what you enjoy building most.</Todo>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="rounded-2xl border border-rule bg-surface p-6">
              <h3 className="text-sm font-semibold">What I&apos;m looking for</h3>
              <p className="mt-2 text-muted">AI / ML engineering roles building LLM applications, RAG systems, agents and the infrastructure to evaluate and deploy them.</p>
              <h3 className="mt-6 text-sm font-semibold">Languages</h3>
              <p className="mt-2 text-muted">English (professional), German (A2, learning B1)</p>
              <a href="#contact" className="mt-6 inline-block text-sm font-medium text-accent hover:underline">Get in touch</a>
            </div>
          </Reveal>
        </div>
      </Section>

      {/* ---------- Experience ---------- */}
      <Section id="experience" title="Experience">
        <Experience />
      </Section>

      {/* ---------- Skills ---------- */}
      <Section id="skills" title="Skills">
        <Skills />
      </Section>

      {/* ---------- Currently building ---------- */}
      <Section id="building" title="Currently building" intro="Work in progress, shown as it is. None of these are finished yet." link={{ href: "/building/", label: "See the roadmaps" }}>
        <ul className="divide-y divide-rule overflow-hidden rounded-2xl border border-dashed border-rule">
          {building.map((b) => (
            <li key={b.slug}>
              <Link href={`/building/#${b.slug}`} className="grid gap-2 p-5 transition-colors hover:bg-surface sm:grid-cols-[2.5rem_1fr_auto] sm:items-center sm:gap-5">
                <span className="hidden font-mono text-sm text-faint sm:block">{b.code}</span>
                <span>
                  <span className="block font-semibold">{b.name}</span>
                  <span className="mt-0.5 block text-sm text-muted">{b.pitch}</span>
                </span>
                <StatusBadge status={b.status} />
              </Link>
            </li>
          ))}
        </ul>
      </Section>

      {/* ---------- Education & certifications ---------- */}
      <Section id="certifications" title="Education & certifications">
        <div className="grid gap-10 md:grid-cols-2">
          <ul className="space-y-6">
            {education.map((e) => (
              <li key={e.degree}>
                <p className="font-mono text-sm text-faint">{e.period}</p>
                <h3 className="mt-1 text-lg font-semibold">{e.degree}</h3>
                <p className="text-muted">{e.school}, {e.place}</p>
              </li>
            ))}
          </ul>
          <ul className="divide-y divide-rule border-y border-rule">
            {certifications.map((c) => (
              <li key={c.name} className="py-4">
                <p className="font-medium">{c.url ? <a href={c.url} target="_blank" rel="noopener" className="hover:text-accent">{c.name}</a> : c.name}</p>
                <p className="text-sm text-muted">{[c.issuer, c.year].filter(Boolean).join(", ")}</p>
                {(!c.issuer || !c.year) && <Todo>Add issuer, year and a credential link</Todo>}
              </li>
            ))}
            <li className="py-4">
              <p className="font-medium">Research publication</p>
              <p className="text-sm text-muted">Paper on the BIT campus AR navigation system, published in IRJET.</p>
              <Todo>Add paper title, year and link</Todo>
            </li>
          </ul>
        </div>
      </Section>

      {/* ---------- GitHub ---------- */}
      <Section id="github" title="On GitHub" intro="Live from my public repositories.">
        <GitHubRepos />
      </Section>

      {/* ---------- Contact ---------- */}
      <Section id="contact" title="Let's talk">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
          <div>
            <p className="text-lg text-muted">Hiring for an AI / ML or software engineering role, or building something with LLMs? I&apos;d like to hear about it.</p>
            <ul className="mt-8 space-y-3">
              <li><a href={`mailto:${site.email}`} className="font-medium text-accent hover:underline">{site.email}</a></li>
              <li><a href={site.linkedin} target="_blank" rel="noopener" className="text-muted hover:text-ink">LinkedIn</a></li>
              <li><a href={site.github} target="_blank" rel="noopener" className="text-muted hover:text-ink">GitHub</a></li>
              <li><Link href="/resume/" className="text-muted hover:text-ink">Resume</Link></li>
            </ul>
          </div>
          <ContactForm />
        </div>
      </Section>
    </>
  );
}
