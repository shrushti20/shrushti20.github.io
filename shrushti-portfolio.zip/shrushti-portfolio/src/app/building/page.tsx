import type { Metadata } from "next";
import { building } from "@/data/building";
import { BuildingCard } from "@/components/BuildingCard";

export const metadata: Metadata = {
  title: "Currently building",
  description: "Planned and in-progress projects: an agentic RAG system, an LLM evaluation platform, an MLOps pipeline and an AI data analyst agent.",
  alternates: { canonical: "/building/" },
};

export default function BuildingPage() {
  return (
    <div className="mx-auto max-w-5xl px-5 py-14 sm:px-8 sm:py-20">
      <h1 className="font-display text-4xl font-extrabold sm:text-5xl">Currently building</h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        These projects are planned or in progress, not finished. Each shows its intended scope, stack and architecture, and the roadmap is updated as milestones are completed.
      </p>
      <div className="mt-12 space-y-6">
        {building.map((b) => <BuildingCard key={b.slug} b={b} />)}
      </div>
    </div>
  );
}
